# CitaIA MVP

MVP comercial de CitaIA, una plataforma SaaS para clínicas estéticas.

## Ejecutar

```bash
npm install
npm run dev
```

Abre http://localhost:3000.

## Próximos pasos

1. Conectar autenticación y base de datos con Supabase.
2. Añadir API de IA.
3. Integrar agenda.
4. Integrar WhatsApp/Instagram.
5. Añadir Stripe para suscripciones.
6. Desplegar en Vercel.

Este MVP incluye landing, demo de chatbot, precios y dashboard visual.
