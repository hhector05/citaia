import "./globals.css";
export const metadata = { title: "CitaIA — IA que convierte consultas en citas", description: "Automatiza la atención de tu clínica estética." };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="es"><body>{children}</body></html>;
}